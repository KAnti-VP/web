window.onload = async function () {
  const kurzusok = await getData('courses')
  Kurzusok_frisitese(kurzusok)
};

function Szin_Kikeverese(str) {
  numbers = str
    .split("")
    .map((c) => c.charCodeAt(0))
    .sort(() => Math.random() - 0.5)
    .join("");
  const red = (parseInt(numbers.slice(0, 3)) / 350) * 256;
  const green = (parseInt(numbers.slice(3, 6)) / 350) * 256;
  const blue = (parseInt(numbers.slice(6, 9)) / 350) * 256;
  return `rgb(${red},${green},${blue})`;
}

function Kurzusok_frisitese(kurzusok) {
  container = document.getElementById("kurzusok");
  container.innerHTML = ``
  kurzusok.forEach((kurzus) => {
    container.innerHTML += `
      <div class="card m-2">
        <div class="card-header">
          ${kurzus.name}
        </div>
        <ul class="list-group list-group-flush">    
          <li class="list-group-item">${JSON.stringify(kurzus.students) == JSON.stringify([]) ? 'no student' : 'list of students'} </li>        
        </ul>
        <div class="card-footer">
          <button class="addButton" onClick="Add_student(${kurzus.id})">+</button>
        </div>
      </div>`
  });
}